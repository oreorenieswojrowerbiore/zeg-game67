// ==========================================
// GRAFIKI
// ==========================================
const wallImg = new Image();
wallImg.src = "assets/wall.png";

const enemyImg = new Image();
enemyImg.src = "assets/enemy.png";

const keyImg = new Image();
keyImg.src = "assets/key.png";

const healImg = new Image();
healImg.src = "assets/heal.png";

const exitImg = new Image();
exitImg.src = "assets/exit.png";

let loadedImages = 0;
const totalImages = 5;

function imageLoaded() {
  loadedImages++;
}

wallImg.onload = imageLoaded;
enemyImg.onload = imageLoaded;
keyImg.onload = imageLoaded;
healImg.onload = imageLoaded;
exitImg.onload = imageLoaded;

// ==========================================
// PLAYER
// ==========================================
let playerDOM = document.getElementById("playerGif");

if (!playerDOM) {
  playerDOM = document.createElement("img");
  playerDOM.id = "playerGif";
  playerDOM.src = "assets/player.gif";
  playerDOM.style.position = "absolute";
  playerDOM.style.zIndex = "10";
  playerDOM.style.pointerEvents = "none";
  playerDOM.style.display = "none";
  document.body.appendChild(playerDOM);
}

window.player = {
  x: 0,
  y: 0,
  hp: 3,
  keys: 0
};

// ==========================================
// KONFIG
// ==========================================
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const menu = document.getElementById("menu");
const tileSize = 40;

let currentLevel = 0;
let levelMap = [];

// ==========================================
// ZAGADKI
// ==========================================
const riddles = {
  0: { question: "Co ma klucze?", answers: ["klawiatura"] },
  1: { question: "Im więcej zabierasz?", answers: ["dziura"] },
  2: { question: "Co nigdy nie stoi?", answers: ["czas"] }
};

let currentRiddlePos = null;

const riddleBox = document.createElement("div");
riddleBox.style = `
position:fixed;
top:50%;
left:50%;
transform:translate(-50%,-50%);
background:#111;
color:white;
padding:20px;
z-index:999;
display:none;
`;
document.body.appendChild(riddleBox);

// ==========================================
// CUTSCENE
// ==========================================
const cutsceneImages = [
  "assets/Fabula 1.png",
  "assets/Fabula 2.png",
  "assets/Fabula 3.png"
];

let cutsceneIndex = 0;

const cutscene = document.createElement("div");
cutscene.style = `
position:fixed;inset:0;
background:black;
display:none;
justify-content:center;
align-items:center;
z-index:999;
cursor:pointer;
`;

const cutsceneImage = document.createElement("img");
cutsceneImage.style.maxWidth = "100%";
cutsceneImage.style.maxHeight = "100%";
cutscene.appendChild(cutsceneImage);
document.body.appendChild(cutscene);

cutscene.onclick = () => {
  cutsceneIndex++;
  if (cutsceneIndex >= cutsceneImages.length) {
    cutscene.style.display = "none";
    window.startGame();
    return;
  }
  cutsceneImage.src = cutsceneImages[cutsceneIndex];
};

// ==========================================
// 🔥 FIX NA START (NAJWAŻNIEJSZE)
// ==========================================
window.startCutscene = function () {
  cutsceneIndex = 0;
  menu.style.display = "none";
  cutscene.style.display = "flex";
  cutsceneImage.src = cutsceneImages[0];
};

// ==========================================
// GAME START
// ==========================================
window.startGame = function () {
  if (loadedImages < totalImages) return alert("Ładowanie...");

  player.hp = 3;
  player.keys = 0;
  currentLevel = 0;

  playerDOM.style.display = "block";

  loadLevel();
  drawGame();
};

// ==========================================
// LEVEL
// ==========================================
function loadLevel() {
  levelMap = levels[currentLevel].map(r => r.split(""));

  canvas.width = levelMap[0].length * tileSize;
  canvas.height = levelMap.length * tileSize;

  for (let y = 0; y < levelMap.length; y++) {
    for (let x = 0; x < levelMap[y].length; x++) {
      if (levelMap[y][x] === "P") {
        player.x = x;
        player.y = y;
        levelMap[y][x] = " ";
      }
    }
  }
}

// ==========================================
// MOVE
// ==========================================
function movePlayer(dx, dy) {
  const nx = player.x + dx;
  const ny = player.y + dy;

  const tile = levelMap[ny][nx];

  if (tile === "#") return;

  if (tile === "K") player.keys++;

  if (tile === "H") player.hp = Math.min(3, player.hp + 1);

  if (tile === "T") {
    player.hp--;
    if (player.hp <= 0) return gameOver();
  }

  if (tile === "E") return nextLevel();

  if (tile === "Z") return showRiddle(nx, ny);

  levelMap[ny][nx] = " ";
  player.x = nx;
  player.y = ny;
}

// ==========================================
// ZAGADKA
// ==========================================
function showRiddle(x, y) {
  const r = riddles[currentLevel] || { question: "brak", answers: [] };

  currentRiddlePos = { x, y };

  riddleBox.innerHTML = `
    <div>${r.question}</div>
    <input id="riddleInput">
    <button onclick="checkRiddle()">OK</button>
  `;

  riddleBox.style.display = "block";
}

window.checkRiddle = function () {
  const input = document.getElementById("riddleInput").value.toLowerCase();
  const r = riddles[currentLevel] || {};

  if (r.answers.includes(input)) {
    const { x, y } = currentRiddlePos;
    levelMap[y][x] = " ";
    riddleBox.style.display = "none";
    drawGame();
  } else {
    alert("Źle!");
  }
};

// ==========================================
// RENDER
// ==========================================
function drawGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (let y = 0; y < levelMap.length; y++) {
    for (let x = 0; x < levelMap[y].length; x++) {

      const t = levelMap[y][x];

      ctx.fillStyle = "#151515";
      ctx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);

      if (t === "#") ctx.drawImage(wallImg, x * tileSize, y * tileSize, tileSize, tileSize);
      if (t === "K") ctx.drawImage(keyImg, x * tileSize, y * tileSize, tileSize, tileSize);
      if (t === "T") ctx.drawImage(enemyImg, x * tileSize, y * tileSize, tileSize, tileSize);
      if (t === "H") ctx.drawImage(healImg, x * tileSize, y * tileSize, tileSize, tileSize);
      if (t === "E") ctx.drawImage(exitImg, x * tileSize, y * tileSize, tileSize, tileSize);
      if (t === "Z") {
        ctx.fillStyle = "purple";
        ctx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
      }
    }
  }

  const rect = canvas.getBoundingClientRect();

  playerDOM.style.left = rect.left + window.scrollX + player.x * tileSize + "px";
  playerDOM.style.top = rect.top + window.scrollY + player.y * tileSize + "px";
  playerDOM.style.width = tileSize + "px";
  playerDOM.style.height = tileSize + "px";

  ctx.fillStyle = "white";
  ctx.fillText("HP:" + player.hp, 10, 20);
}

// ==========================================
// NEXT / GAME OVER
// ==========================================
window.nextLevel = function () {
  currentLevel++;
  if (currentLevel >= levels.length) {
    alert("WIN");
    menu.style.display = "flex";
    playerDOM.style.display = "none";
    return;
  }
  loadLevel();
  drawGame();
};

window.gameOver = function () {
  alert("GAME OVER");
  menu.style.display = "flex";
  playerDOM.style.display = "none";
};

// ==========================================
// INPUT
// ==========================================
document.addEventListener("keydown", e => {
  if (menu.style.display !== "none") return;

  const k = e.key.toLowerCase();

  if (k === "w") movePlayer(0, -1);
  if (k === "s") movePlayer(0, 1);
  if (k === "a") movePlayer(-1, 0);
  if (k === "d") movePlayer(1, 0);

  drawGame();
});